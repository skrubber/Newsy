var express = require('express');
var app = express();
var fs = require('fs');
var path = require('path');
var LinkModule = require('docxtemplater-link-module');
var linkModule = new LinkModule();
var ImageModule = require('docxtemplater-image-module')
var opts = {}
opts.centered = false;
opts.getImage = function (tagValue, tagName) {
    return fs.readFileSync(tagValue);
}
opts.getSize = function (img, tagValue, tagName) {
    return [300, 150];
}

var imageModule = new ImageModule(opts);
app.use(function (req, res, next) {
    //Enabling CORS 
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,POST,PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept");
    next();
});
//   app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(express.json());
app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/jsfiles'));
app.use(express.static(__dirname + '/csvfiles'));
app.use(express.static(__dirname + '/css'));
app.use(express.static(__dirname + '/images'));
app.use(express.static(__dirname + '/documents'));
app.get('/doc/:id', (req, res) => {

    try {
        var csvjson = require('csvjson');
        var options = {
            delimiter: ',', // optional
            quote: '"' // optional
        };
        var file_data = fs.readFileSync(path.resolve(__dirname, 'csvfiles/rivals.csv'), { encoding: 'utf8' });
        var result = csvjson.toObject(file_data, options);
        var companydata = result.filter((data) => data.rival === req.params.id.toLowerCase());
        var acquisitions_data = (companydata.filter((data) => data.ranked === '5'));
        var investment_data = (companydata.filter((data) => data.ranked === '4'));
        var partnership_data = (companydata.filter((data) => data.ranked === '3'));
        var lookforward_data = (companydata.filter((data) => data.ranked === '2'));
        var emptydata = {
            'industry': '-',
            'Company': '-',
            'newlink': '-'
        }
        var final = [];
        for (var i = 0; i < acquisitions_data.length; i++) {
             final[i] = (acquisitions_data[i].title).slice(0, 30);
             acquisitions_data[i].newlink = final[i];
        }
        var final1 = [];
        for (var i = 0; i < investment_data.length; i++) {
             final1[i] = (investment_data[i].title).slice(0, 30);
             investment_data[i].newlink = final1[i];
        }
        var final2 = [];
        for (var i = 0; i < partnership_data.length; i++) {
             final2[i] = (partnership_data[i].title).slice(0, 30);
             partnership_data[i].newlink = final2[i];
        }
        var final3 = [];
        for (var i = 0; i < lookforward_data.length; i++) {
             final3[i] = (lookforward_data[i].title).slice(0, 30);
             lookforward_data[i].newlink = final3[i];
        }
        // grouped=[];
        // acquisitions_data.forEach(function (a) {
        //       grouped[a.industry] = grouped[a.industry] || [];
        //      grouped[a.industry].push({ Company: a.Company, newlink: a.newlink });
        // });console.log(grouped);
        if (acquisitions_data.length == 0) { data = emptydata } else { data = acquisitions_data }
        if (investment_data.length == 0) { data1 = emptydata } else { data1 = investment_data }
        if (partnership_data.length == 0) { data2 = emptydata } else { data2 = partnership_data }
        if (lookforward_data.length == 0) { data3 = emptydata } else { data3 = lookforward_data }
        var DocxGen = require('docxtemplater');
        var content = fs.readFileSync(__dirname + "/documents/input.docx", "binary");
        var docx = new DocxGen()
            .attachModule(linkModule)
            .load(content)
            .setData({
                date: companydata[0].Dated,
                heading: 'Competitor Deal Engagement Overview',
                industry_name: req.params.id,
                over_view_heading: 'Investment Themes Overview',
                no_of_acquisitions: acquisitions_data.length,
                no_of_investments: investment_data.length,
                no_of_partnerships: partnership_data.length,
                no_of_look_forwards: lookforward_data.length,
                acquisition_table: data,
                investment_table: data1,
                partnership_table: data2,
                lookforward_table: data3,

            }).
            render();
        var buffer = docx
            .getZip()
            .generate({ type: "nodebuffer" });
        fs.writeFile(path.resolve(__dirname, 'documents/' + `${req.params.id}` + '.docx'), buffer);
    }
    catch (error) {
        var e = {
            message: error.message,
            name: error.name,
            stack: error.stack,
            properties: error.properties,
        }
        console.log(JSON.stringify({ error: e }));
        // The error thrown here contains additional information when logged with JSON.stringify (it contains a property object).
        throw error;
    }
    res.send({ 'CompanyID': req.params.id });
});
app.listen(4000, () => {
    console.log("port is listening");
})